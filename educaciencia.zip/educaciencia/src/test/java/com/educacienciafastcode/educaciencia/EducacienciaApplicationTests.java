package com.educacienciafastcode.educaciencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducacienciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
