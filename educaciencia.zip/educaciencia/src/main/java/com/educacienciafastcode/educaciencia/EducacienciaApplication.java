package com.educacienciafastcode.educaciencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducacienciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducacienciaApplication.class, args);
	}

}
